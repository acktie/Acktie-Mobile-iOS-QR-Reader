A fully working example for this module is available on github at https://github.com/acktie/Acktie-Mobile-QR-Example

The example images are under the Resources/images directory on github: https://github.com/acktie/Acktie-Mobile-QR-Example/tree/master/Resources/images

Tony Nuzzi @ Acktie

Twitter: @Acktie

Email: support@acktie.com